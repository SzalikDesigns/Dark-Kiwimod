
ES-Theme-Dark-Kiwimod-RG351

https://github.com/RiseAgainst88


Dark ES-Theme with a more Adult-Like Look Based on ArkOS for the RG351P/M. 
The Base of this mod is Hursky`s SuperSweet Theme.

The recommended Gamelist View Style is "Video"


Supported Platforms:

3do
Amiga
Amiga 32
Amstrad CPC
Arcade
Atomiswave
Atari 800
Atari 2600
Atari 5200
Atari 7800
Atari Jaguar
Atari Lynx
Atari ST
Atari Xegs
auto-allgames
auto-favorites
auto-lastplayed
Coleco
Commodore 16
Commodore 64/VIC-20/PET
Commodore 128
cps1
cps2
cps3
Daphne
Doom
DOS/PC
Dreamcast
Dreamcast VMU
EasyRPG
Famicom Disk System
Gamegear
Gameboy
Gameboy Advance
Gameboy Color
Game and Watch
Genesis
Intellivision
Mame 2003
Mame 2010
Master System
Megadrive
MSX
MSX2
Naomi
Neo Geo
Neo Geo CD
Neo Geo Pocket
Neo Geo Pocket Color
Nintendo 64
Nintendo 64DD
Nintendo DS
Nintendo 3DS
Odyssey2
PC98
PC Engine
PC Engine CD
PC-FX
Pokemon Mini
Ports
PlayStation
PlayStation Portable
Playstation Portable Minis
RetroArch
Retropie/Options
ScummVM
Sega 32X
Sega CD
Sega Saturn
SG 1000
Sharp X1
Sharp X68000
Solarus
SuFami Turbo
Super Grafx
Super Nintendo
Super Nintendo Hacks
Super Nintendo MSU1
Super Famicom
Tic-80
TI-99
TurboGrafx-16
TurboGraphx CD
Uzebox
Vectrex
Virtual Boy
WonderSwan
WonderSwan Color
ZX Spectrum
Sinclair ZX81
LowRes NX
sc-3000
pc
pico-8
residualvm
megacd